<?php
	try{
		$pdo = new PDO('mysql:host=localhost;dbname=hostelmanagementsystemdb','root','');
	}
	catch(PDOException $e){
		exit('Database error');
	}
?>