<?php
include("includes/connection.php");
include("includes/functions.php");
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

if (isset($_SESSION['adminUsername'])) {
    date_default_timezone_set('Asia/Calcutta');

    if (isset($_POST['addRoom'])) {
        $totalNumberOfBeds = $_POST['totalNumberOfBeds'];
        $rentPerMonth = $_POST['rentPerMonth'];
        $deposit = $_POST['deposit'];
        $adminId = $_POST['adminId'];

        $adminDashboard = new adminDashboard;
        $roomDetails = $adminDashboard->addRoom($totalNumberOfBeds, $rentPerMonth, $deposit, $adminId);
    }

?>

    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css">

        <title>Dashboard</title>
        <style>
            @import url('../style/style.css');

            .container{
                display:grid;
                grid-template-columns: 50% 40%;
                width:100%;
            }

            .hostel-details{
                padding-left:10%;
            }

            .form h4 {
                display: block;
                margin: 0 auto;
                width: 50%;
                text-align: center;
            }

            .form p {
                width: 80%;
                margin: 0 auto;
            }
        </style>
    </head>

    <body style="padding-top:10%;">

        <?php
        include("includes/navRight.php");
        include("includes/navLeft.php");

        // getting admin id 
        $fetchAdminDetails = new adminDashboard;
        $adminDetails = $fetchAdminDetails->fetchAdminDetails();

        ?>

        <div class="container">
            <div class="hostel-details">
                <p>Welcome <?php echo $adminDetails['adminName'];?> ! Have a good day.</p>
                <span>Hostel Id : <?php echo $adminDetails['adminId'];?> </span>
                <h3><?php echo $adminDetails['hostelName'];?> </h3>
                <p>Total rooms : <br>
                    Rented rooms : <br>
                    Vacant rooms : <br>
                    Pending applications : </p>
            </div>

            <form action="dashboard.php" class="form" method="post">
                <h4>Add New Rooms</h4>
                <input type="text" name="totalNumberOfBeds" placeholder="no Of beds">
                <input type="text" name="rentPerMonth" placeholder="rent per month">
                <input type="text" name="deposit" placeholder="deposit">
                <input type="hidden" name="adminId" value="<?php echo $adminDetails['adminId']; ?>">
                <p>Each Room will have : <br>
                    1 Table <br>
                    1 Fan <br>
                    1 Cupboard with full length mirror
                </p>
                <input type="submit" value="Add" name="addRoom">

            </form>
        </div>

    </body>

    </html>

<?php
} else {
    header('Location:index.php');
}
?>