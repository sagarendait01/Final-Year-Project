<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Cormorant+Garamond:wght@700&family=Proza+Libre&display=swap');

        @import url("rootselector.css");

        :root {
            --heading-font: 'Cormorant Garamond', sans-serif;
            --body-font: 'Proza Libre', sans-serif;
            --primary-color: #251A5F;
            --hover-color: #0A013E;
            --disabled-color: #9E99B8;
            --primary-text-color: #121212;
            --dark-background-text-color: #e6e6e6;
        }

        h3 {
            padding:10%;
            margin:0 auto;
            background-color: var(--primary-color);
        }
    </style>
</head>

<body>
    <h3>hey there</h3>
    <p>Et ipsum non et minim adipisicing cillum voluptate non veniam. Eiusmod do dolore deserunt exercitation in reprehenderit ullamco proident dolore magna ad excepteur. Est amet excepteur magna et. Irure adipisicing deserunt dolor Lorem minim minim ullamco cupidatat ut.</p>
</body>

</html>