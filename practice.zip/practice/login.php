<?php
if (isset($_POST['adminLogin'])) {
    $adminUsername = $_POST['adminUsername'];
    $adminPassword = $_POST['adminPassword'];

    $adminDashboard = new adminDashboard;
    $adminDetails = $adminDashboard->adminLogin($adminUsername, $adminPassword);
}
?>
<form action="index.php" method="post" class="form">
    <h3>Login</h3>
    <input type="text" name="adminUsername" placeholder="Username">
    <input type="password" name="adminPassword" placeholder="Password">
    <a href="forgotPassword.php">Forgot Password?</a>
    <input type="submit" value="Login" name="adminLogin">
</form>