<?php 
     if(isset($_POST['adminSignup'])){
        $adminName = $_POST['adminName'];
        $adminEmail = $_POST['adminEmail'];
        $adminMobileNumber = $_POST['adminMobileNumber'];
        $adminPassword = $_POST['adminPassword'];
        $hostelName = $_POST['hostelName'];

        $adminDashboard = new adminDashboard;
        $adminDetails = $adminDashboard->saveSignupDetails($adminName,$adminEmail,$adminMobileNumber,$adminPassword,$hostelName);

        if($adminDetails == TRUE)
        {
            echo "
            <script>
                alert('You have successfully registered on our system. Login to proceed.');
            </script>";
        }
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
                <form action="index.php" method="post" class="form">
                    <h3>Signup</h3>
                    <input type="text" name="adminName" placeholder="Name">
                    <input type="text" name="adminMobileNumber" placeholder="Mobile Number">
                    <input type="email" name="adminEmail" placeholder="Email">
                    <input type="password" name="adminPassword" placeholder="Create Password">
                    <input type="text" name="hostelName" placeholder="Hostel Name">
                    <input type="submit" value="Signup" name="adminSignup">
                </form>
</body>
</html>