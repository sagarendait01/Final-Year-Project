<?php 
    include("connection.php");

    class name{
        public function getname(){
            global $pdo;

            $query = $pdo->prepare("SELECT * FROM rooms");
            $query->execute();


            $result = $query->fetchAll();
            return $result;
        }
    }
?>