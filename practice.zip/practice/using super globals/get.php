<?php
    $name = $_GET['name'];
    echo $name;
?>

